    setInterval(function () {
      var win = $(window),
        aspect = 1366 / 768; //this = window
      if (win.width() <= 1365) {
        $('.infographic-container').css('width', win.width());
        $('.infographic-container').css('height', 'auto');
        $('svg').css('width', win.width());
        $('svg').css('height', win.width() / aspect);
      }
      if (win.height() <= win.width() / aspect) {
        $('.infographic-container').css('height', win.height());
        $('.infographic-container').css('width', 'auto');
        $('svg').css('height', win.height());
      }
      if ((win.height() >= 768) && (win.width() >= 1366)) {
        $('.infographic-container').css('height', 768);
        $('.infographic-container').css('width', '100%');
        $('svg').css('height', '100%');
        $('svg').css('width', '100%');
      }
//      if ($('.infographic-container').width() <= 768) {
//        var tl = new TimelineMax();
//                
//        tl.to($('#Resting_View'), .5, {ease: Power3.easeOut, opacity: 0}, 0);
//        tl.to($('.small-image-left'), .5, {x: -425, y: 25, scale: 1.5}, 0);
//        tl.to($('.small-screen-left'), .5, {x: 100, y: -25, scale: 1.35}, 0);
//        tl.to($('.small-screen-left-text'), .5, {x: -48, y: -200, scale: 1.35}, 0);
//        tl.to($('#Animation_Human-body__x28_Left-side_x29_'), .5, {ease: Power3.easeOut, opacity: 1, scale: 2, x: -100}, 0);
//        $('svg').css({'position': 'relative',
//                      'width': '100%',
//                      'transform': 'translateY(-37%)',
//                      'height': '180%'});
//        $('.infographic-container').css({'height': win.width()*3.2 / aspect,
//                                         'overflow': 'hidden'});
//      } else {    
//      }
    }, 0.01)

$('.proteins__left').hover(function() {
  var tl = new TimelineMax(),
      rest = $('#Resting_View'),
      left = $('#Animation_Human-body__x28_Left-side_x29_');
  
  tl.to(left, 1.5, {ease: Power3.easeOut, opacity: 1}, 0);  
  tl.to(rest, 1.5, {ease: Power3.easeOut, opacity: 0}, 0);  
}, function(){
  var tl = new TimelineMax(),
      rest = $('#Resting_View'),
      left = $('#Animation_Human-body__x28_Left-side_x29_');
  
  tl.to(left, 1.5, {ease: Power3.easeOut, opacity: 0}, 0);  
  tl.to(rest, 1.5, {ease: Power3.easeOut, opacity: 1}, 0); 
})
$('.proteins__center').hover(function() {
  var tl = new TimelineMax(),
      rest = $('#Resting_View'),
      center = $('#Animation_Body-anatomy__x28_middle_x29_');
  
  tl.to(center, 1.5, {ease: Power3.easeOut, opacity: 1}, 0);  
  tl.to(rest, 1.5, {ease: Power3.easeOut, opacity: 0}, 0);  
}, function(){
  var tl = new TimelineMax(),
      rest = $('#Resting_View'),
      center = $('#Animation_Body-anatomy__x28_middle_x29_');
  
  tl.to(center, 1.5, {ease: Power3.easeOut, opacity: 0}, 0);  
  tl.to(rest, 1.5, {ease: Power3.easeOut, opacity: 1}, 0); 
})
$('.proteins__right').hover(function() {
  var tl = new TimelineMax(),
      rest = $('#Resting_View'),
      right = $('#Animation_Skeleton__x28_right-side_x29_');
  
  tl.to(right, 1.5, {ease: Power3.easeOut, opacity: 1}, 0);  
  tl.to(rest, 1.5, {ease: Power3.easeOut, opacity: 0}, 0);  
}, function(){
  var tl = new TimelineMax(),
      rest = $('#Resting_View'),
      right = $('#Animation_Skeleton__x28_right-side_x29_');
  
  tl.to(right, 1.5, {ease: Power3.easeOut, opacity: 0}, 0);  
  tl.to(rest, 1.5, {ease: Power3.easeOut, opacity: 1}, 0); 
})